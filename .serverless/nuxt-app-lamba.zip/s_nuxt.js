
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'regiosoft',
  applicationName: 'nuxt',
  appUid: '9yG0bpPRDN91Gy0kBj',
  orgUid: '01c154f9-e740-41be-a010-03c486e7dc74',
  deploymentUid: 'f435979a-a550-4f40-95eb-995f7240263b',
  serviceName: 'nuxt-app-lamba',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'nuxt-app-lamba-dev-nuxt', timeout: 6 };

try {
  const userHandler = require('./.output/server/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}