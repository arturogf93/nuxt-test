globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node-fetch-native/polyfill';
import 'ufo';
export { h as handler } from './chunks/nitro/aws-lambda.mjs';
import 'h3';
import 'ohmyfetch';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
//# sourceMappingURL=index.mjs.map
