import { w as welcome_vue_vue_type_style_index_0_scoped_25102a06_lang } from '../styles.mjs';

const welcomeStyles_84d3e35e = [welcome_vue_vue_type_style_index_0_scoped_25102a06_lang];

export { welcomeStyles_84d3e35e as default };
//# sourceMappingURL=welcome-styles.84d3e35e.mjs.map
